
public class FactoryClass {
	public String NameTag  ;
	public int Index;
	public int Xpos ;
	public int Ypos;

	public FactoryClass(String Name, int Index,int Xpos,int Ypos)
	{
		this.NameTag = Name;
		this.Index = Index;
		this.Xpos = Xpos;
		this.Ypos = Ypos;
		
	}
	
	
	
}
